local n=require"nixio.fs"
local r=require"luci.sys"
local a=require"luci.util"
local t=require"luci.http"
local f=require"nixio",require"nixio.util"
module("luci.dispatcher",package.seeall)
context=a.threadlocal()
uci=require"luci.model.uci"
i18n=require"luci.i18n"
_M.fs=n
local h=nil
local e
function build_url(...)
local a={...}
local e={t.getenv("SCRIPT_NAME")or""}
local t
for a,t in ipairs(a)do
if t:match("^[a-zA-Z0-9_%-%.%%/,;]+$")then
e[#e+1]="/"
e[#e+1]=t
end
end
if#a==0 then
e[#e+1]="/"
end
return table.concat(e,"")
end
function node_visible(e)
if e then
return not(
(not e.title or#e.title==0)or
(not e.target or e.hidden==true)or
(type(e.target)=="table"and e.target.type=="firstchild"and
(type(e.nodes)~="table"or not next(e.nodes)))
)
end
return false
end
function node_childs(e)
local t={}
if e then
local o,o
for a,e in a.spairs(e.nodes,
function(t,a)
return(e.nodes[t].order or 100)
<(e.nodes[a].order or 100)
end)
do
if node_visible(e)then
t[#t+1]=a
end
end
end
return t
end
function error404(e)
t.status(404,"Not Found")
e=e or"Not Found"
require("luci.template")
if not a.copcall(luci.template.render,"error404")then
t.prepare_content("text/plain")
t.write(e)
end
return false
end
function error500(e)
a.perror(e)
if not context.template_header_sent then
t.status(500,"Internal Server Error")
t.prepare_content("text/plain")
t.write(e)
else
require("luci.template")
if not a.copcall(luci.template.render,"error500",{message=e})then
t.prepare_content("text/plain")
t.write(e)
end
end
return false
end
function httpdispatch(n,o)
t.context.request=n
local e={}
context.request=e
local i=require"nixio.fs"
local i=i.access("/etc/config/wizard")and(not i.access("/etc/config/finished"))and"admin/wizard"or""
local i=t.urldecode(n:getenv("PATH_INFO")or i,true)
if o then
for a,t in ipairs(o)do
e[#e+1]=t
end
end
for t in i:gmatch("[^/]+")do
e[#e+1]=t
end
local e,e=a.coxpcall(function()
dispatch(context.request)
end,error500)
t.close()
end
local function y(e)
if type(e)=="table"then
if type(e.post)=="table"then
local o,o,a
for o,e in pairs(e.post)do
a=t.formvalue(o)
if(type(e)=="string"and
a~=e)or
(e==true and
(a==nil or a==""))
then
return false
end
end
return true
end
return(e.post==true)
end
return false
end
function test_post_security()
if t.getenv("REQUEST_METHOD")~="POST"then
t.status(405,"Method Not Allowed")
t.header("Allow","POST")
return false
end
if t.formvalue("token")~=context.authtoken then
t.status(403,"Forbidden")
luci.template.render("csrftoken")
return false
end
return true
end
local function c(t,o)
local e=a.ubus("session","get",{ubus_rpc_session=t})
if type(e)=="table"and
type(e.values)=="table"and
type(e.values.token)=="string"and
(not o or
a.contains(o,e.values.username))
then
return t,e.values
end
return nil,nil
end
local function w(e,o,t)
if a.contains(t,e)then
local e=a.ubus("session","login",{
username=e,
password=o,
timeout=tonumber(luci.config.sauth.sessiontime)
})
if type(e)=="table"and
type(e.ubus_rpc_session)=="string"
then
a.ubus("session","set",{
ubus_rpc_session=e.ubus_rpc_session,
values={token=r.uniqueid(16)}
})
return c(e.ubus_rpc_session)
end
end
return nil,nil
end
function dispatch(s)
local i=context
i.path=s
local o=require"luci.config"
assert(o.main,
"/etc/config/luci seems to be corrupt, unable to find section 'main'")
local d=require"luci.i18n"
local e=o.main.lang or"auto"
if e=="auto"then
local t=t.getenv("HTTP_ACCEPT_LANGUAGE")or""
for t in t:gmatch("[%w-]+")do
t=t and t:gsub("-","_")
if o.languages[t]then
e=t
break
end
end
end
if e=="auto"then
e=d.default
end
d.setlanguage(e)
local e=i.tree
local o
if not e then
e=createtree()
end
local o={}
local h={}
i.args=h
i.requestargs=i.requestargs or h
local m
local u={}
local l={}
for i,t in ipairs(s)do
u[#u+1]=t
l[#l+1]=t
e=e.nodes[t]
m=i
if not e then
break
end
a.update(o,e)
if e.leaf then
break
end
end
if e and e.leaf then
for e=m+1,#s do
h[#h+1]=s[e]
l[#l+1]=s[e]
end
end
i.requestpath=i.requestpath or l
i.path=u
if o.i18n then
d.loadc(o.i18n)
end
if(e and e.index)or not o.notemplate then
local e=require("luci.template")
local o=o.mediaurlbase or luci.config.main.mediaurlbase
if not pcall(e.Template,"themes/%s/header"%n.basename(o))then
o=nil
for a,t in pairs(luci.config.themes)do
if a:sub(1,1)~="."and pcall(e.Template,
"themes/%s/header"%n.basename(t))then
o=t
end
end
assert(o,"No valid theme found")
end
local function s(i,o,t)
if i then
local e=getfenv(3)
local i=(type(e.self)=="table")and e.self
if type(t)=="table"then
if not next(t)then
return''
else
t=a.serialize_json(t)
end
end
return string.format(
' %s="%s"',tostring(o),
a.pcdata(tostring(t
or(type(e[o])~="function"and e[o])
or(i and type(i[o])~="function"and i[o])
or""))
)
else
return''
end
end
e.context.viewns=setmetatable({
write=t.write;
include=function(t)e.Template(t):render(getfenv(2))end;
translate=d.translate;
translatef=d.translatef;
export=function(t,a)if e.context.viewns[t]==nil then e.context.viewns[t]=a end end;
striptags=a.striptags;
pcdata=a.pcdata;
media=o;
theme=n.basename(o);
resource=luci.config.main.resourcebase;
ifattr=function(...)return s(...)end;
attr=function(...)return s(true,...)end;
url=build_url;
},{__index=function(t,e)
if e=="controller"then
return build_url()
elseif e=="REQUEST_URI"then
return build_url(unpack(i.requestpath))
elseif e=="token"then
return i.authtoken
else
return rawget(t,e)or _G[e]
end
end})
end
o.dependent=(o.dependent~=false)
assert(not o.dependent or not o.auto,
"Access Violation\nThe page at '"..table.concat(s,"/").."/' "..
"has no parent node so the access to this location has been denied.\n"..
"This is a software bug, please report this message at "..
"https://github.com/openwrt/luci/issues"
)
if o.sysauth then
local a=o.sysauth_authenticator
local d,e,n,h,s
if type(a)=="string"and a~="htmlauth"then
error500("Unsupported authenticator %q configured"%a)
return
end
if type(o.sysauth)=="table"then
h,s=nil,o.sysauth
else
h,s=o.sysauth,{o.sysauth}
end
if type(a)=="function"then
d,e=a(r.user.checkpasswd,s)
else
e=t.getcookie("sysauth")
end
e,n=c(e,s)
if not(e and n)and a=="htmlauth"then
local a=t.getenv("HTTP_AUTH_USER")
local r=t.getenv("HTTP_AUTH_PASS")
if a==nil and r==nil then
a=t.formvalue("luci_username")
r=t.formvalue("luci_password")
end
e,n=w(a,r,s)
if not e then
local e=require"luci.template"
context.path={}
t.status(403,"Forbidden")
e.render(o.sysauth_template or"sysauth",{
duser=h,
fuser=a
})
return
end
t.header("Set-Cookie",'sysauth=%s; path=%s'%{e,build_url()})
t.redirect(build_url(unpack(i.requestpath)))
end
if not e or not n then
t.status(403,"Forbidden")
return
end
i.authsession=e
i.authtoken=n.token
i.authuser=n.username
end
if e and y(e.target)then
if not test_post_security(e)then
return
end
end
if o.setgroup then
r.process.setgroup(o.setgroup)
end
if o.setuser then
r.process.setuser(o.setuser)
end
local t=nil
if e then
if type(e.target)=="function"then
t=e.target
elseif type(e.target)=="table"then
t=e.target.target
end
end
if e and(e.index or type(t)=="function")then
i.dispatched=e
i.requested=i.requested or i.dispatched
end
if e and e.index then
local e=require"luci.template"
if a.copcall(e.render,"indexer",{})then
return true
end
end
if type(t)=="function"then
a.copcall(function()
local a=getfenv(t)
local o=require(e.module)
local e=setmetatable({},{__index=
function(t,e)
return rawget(t,e)or o[e]or a[e]
end})
setfenv(t,e)
end)
local i,o
if type(e.target)=="table"then
i,o=a.copcall(t,e.target,unpack(h))
else
i,o=a.copcall(t,unpack(h))
end
assert(i,
"Failed to execute "..(type(e.target)=="function"and"function"or e.target.type or"unknown")..
" dispatcher target for entry '/"..table.concat(s,"/").."'.\n"..
"The called action terminated with an exception:\n"..tostring(o or"(unknown)"))
else
local e=node()
if not e or not e.target then
error404("No root node was registered, this usually happens if no module was installed.\n"..
"Install luci-mod-admin-full and retry. "..
"If the module is already installed, try removing the /tmp/luci-indexcache file.")
else
error404("No page is registered at '/"..table.concat(s,"/").."'.\n"..
"If this url belongs to an extension, make sure it is properly installed.\n"..
"If the extension was recently installed, try removing the /tmp/luci-indexcache file.")
end
end
end
function createindex()
local e={}
local o="%s/controller/"%a.libpath()
local t,t
for t in(n.glob("%s*.lua"%o)or function()end)do
e[#e+1]=t
end
for t in(n.glob("%s*/*.lua"%o)or function()end)do
e[#e+1]=t
end
if indexcache then
local a=n.stat(indexcache,"mtime")
if a then
local t=0
for a,e in ipairs(e)do
local e=n.stat(e,"mtime")
t=(e and e>t)and e or t
end
if a>t and r.process.info("uid")==0 then
assert(
r.process.info("uid")==n.stat(indexcache,"uid")
and n.stat(indexcache,"modestr")=="rw-------",
"Fatal: Indexcache is not sane!"
)
h=loadfile(indexcache)()
return h
end
end
end
h={}
for t,e in ipairs(e)do
local t="luci.controller."..e:sub(#o+1,#e-4):gsub("/",".")
local a=require(t)
assert(a~=true,
"Invalid controller file found\n"..
"The file '"..e.."' contains an invalid module line.\n"..
"Please verify whether the module name is set to '"..t..
"' - It must correspond to the file path!")
local a=a.index
assert(type(a)=="function",
"Invalid controller file found\n"..
"The file '"..e.."' contains no index() function.\n"..
"Please make sure that the controller contains a valid "..
"index function and verify the spelling!")
h[t]=a
end
if indexcache then
local e=f.open(indexcache,"w",600)
e:writeall(a.get_bytecode(h))
e:close()
end
end
function createtree()
if not h then
createindex()
end
local e=context
local o={nodes={},inreq=true}
local t={}
e.treecache=setmetatable({},{__mode="v"})
e.tree=o
e.modifiers=t
require"luci.i18n".loadc("base")
local e=setmetatable({},{__index=luci.dispatcher})
for a,t in pairs(h)do
e._NAME=a
setfenv(t,e)
t()
end
local function i(a,e)
return t[a].order<t[e].order
end
for a,t in a.spairs(t,i)do
e._NAME=t.module
setfenv(t.func,e)
t.func()
end
return o
end
function modifier(e,t)
context.modifiers[#context.modifiers+1]={
func=e,
order=t or 0,
module
=getfenv(2)._NAME
}
end
function assign(e,t,o,a)
local e=node(unpack(e))
e.nodes=nil
e.module=nil
e.title=o
e.order=a
setmetatable(e,{__index=_create_node(t)})
return e
end
function entry(e,o,t,a)
local e=node(unpack(e))
e.target=o
e.title=t
e.order=a
e.module=getfenv(2)._NAME
return e
end
function get(...)
return _create_node({...})
end
function node(...)
local e=_create_node({...})
e.module=getfenv(2)._NAME
e.auto=nil
return e
end
function _create_node(t)
if#t==0 then
return context.tree
end
local a=table.concat(t,".")
local e=context.treecache[a]
if not e then
local i=table.remove(t)
local o=_create_node(t)
e={nodes={},auto=true}
if o.inreq and context.path[#t+1]==i then
e.inreq=true
end
o.nodes[i]=e
context.treecache[a]=e
end
return e
end
function _firstchild()
local a={unpack(context.path)}
local e=table.concat(a,".")
local e=context.treecache[e]
local t
if e and e.nodes and next(e.nodes)then
local a,a
for a,o in pairs(e.nodes)do
if not t or
(o.order or 100)<(e.nodes[t].order or 100)
then
t=a
end
end
end
assert(t~=nil,
"The requested node contains no childs, unable to redispatch")
a[#a+1]=t
dispatch(a)
end
function firstchild()
return{type="firstchild",target=_firstchild}
end
function alias(...)
local e={...}
return function(...)
for a,t in ipairs({...})do
e[#e+1]=t
end
dispatch(e)
end
end
function rewrite(t,...)
local o={...}
return function(...)
local e=a.clone(context.dispatched)
for t=1,t do
table.remove(e,1)
end
for a,t in ipairs(o)do
table.insert(e,a,t)
end
for a,t in ipairs({...})do
e[#e+1]=t
end
dispatch(e)
end
end
local function a(e,...)
local t=getfenv()[e.name]
assert(t~=nil,
'Cannot resolve function "'..e.name..'". Is it misspelled or local?')
assert(type(t)=="function",
'The symbol "'..e.name..'" does not refer to a function but data '..
'of type "'..type(t)..'".')
if#e.argv>0 then
return t(unpack(e.argv),...)
else
return t(...)
end
end
function call(e,...)
return{type="call",argv={...},name=e,target=a}
end
function post_on(t,e,...)
return{
type="call",
post=t,
argv={...},
name=e,
target=a
}
end
function post(...)
return post_on(true,...)
end
local e=function(e,...)
require"luci.template".render(e.view)
end
function template(t)
return{type="template",view=t,target=e}
end
local function d(e,...)
local o=require"luci.cbi"
local h=require"luci.template"
local a=require"luci.http"
local t=e.config or{}
local o=o.load(e.model,...)
local e=nil
for o,a in ipairs(o)do
a.flow=t
local t=a:parse()
if t and(not e or t<e)then
e=t
end
end
local function i(e)
return type(e)=="table"and build_url(unpack(e))or e
end
if t.on_valid_to and e and e>0 and e<2 then
a.redirect(i(t.on_valid_to))
return
end
if t.on_changed_to and e and e>1 then
a.redirect(i(t.on_changed_to))
return
end
if t.on_success_to and e and e>0 then
a.redirect(i(t.on_success_to))
return
end
if t.state_handler then
if not t.state_handler(e,o)then
return
end
end
a.header("X-CBI-State",e or 0)
if not t.noheader then
h.render("cbi/header",{state=e})
end
local i
local a
local r=false
local s=true
local n={}
for t,e in ipairs(o)do
if e.apply_needed and e.parsechain then
local t
for t,e in ipairs(e.parsechain)do
n[#n+1]=e
end
r=true
end
if e.redirect then
i=i or e.redirect
end
if e.pageaction==false then
s=false
end
if e.message then
a=a or{}
a[#a+1]=e.message
end
end
for e,t in ipairs(o)do
t:render({
firstmap=(e==1),
applymap=r,
redirect=i,
messages=a,
pageaction=s,
parsechain=n
})
end
if not t.nofooter then
h.render("cbi/footer",{
flow=t,
pageaction=s,
redirect=i,
state=e,
autoapply=t.autoapply
})
end
end
function cbi(e,t)
return{
type="cbi",
post={["cbi.submit"]="1"},
config=t,
model=e,
target=d
}
end
local function o(e,...)
local t={...}
local a=#t>0 and e.targets[2]or e.targets[1]
setfenv(a.target,e.env)
a:target(unpack(t))
end
function arcombine(t,e)
return{type="arcombine",env=getfenv(),target=o,targets={t,e}}
end
local function n(e,...)
local t=require"luci.cbi"
local o=require"luci.template"
local i=require"luci.http"
local a=luci.cbi.load(e.model,...)
local e=nil
for a,t in ipairs(a)do
local t=t:parse()
if t and(not e or t<e)then
e=t
end
end
i.header("X-CBI-State",e or 0)
o.render("header")
for t,e in ipairs(a)do
e:render()
end
o.render("footer")
end
function form(e)
return{
type="cbi",
post={["cbi.submit"]="1"},
model=e,
target=n
}
end
translate=i18n.translate
function _(e)
return e
end
